def
    s = 0
    for i in range(1, ):
        s = 
    return 


s1 = 
s2 = 
print(s1, s2)

input("运行完毕，请按回车键退出...")
