s = 0
for i in range(1, 101):
    s = s + 1 / i

print("所求和为：", s)

input("运行完毕，请按回车键退出...")


