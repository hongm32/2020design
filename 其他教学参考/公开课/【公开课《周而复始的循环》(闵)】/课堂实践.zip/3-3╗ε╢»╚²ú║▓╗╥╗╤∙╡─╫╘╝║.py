day = 0    # 设置天数初始值为0天
level = 1  # 设置水平初始值为1

b = float(input("你每天多/少努力多少  正数代表多努力、负数代表少努力"))
if b > 0:                                           # 如果输入的是正数（正数代表进步）
    a = float(input("你想进步多少倍于现在的自己"))  # 目标倍数存入变量a
    while level <= a:                               # 当前进步的倍数小于目标倍数时
        level = level * (1 + b)                     # 当前进步倍数更新一次
        day += 1                                    # 天数+1
    print("你需要", day, "天", "就能达到原来的", level, "倍")
elif b < 0:                                         # 如果输入的是负数（负数代表退步）
    a = float(input("你想退步多少倍于自己"))        # 目标倍数存入变量a
    while level >= a:                               # 当前进步的倍数小于目标倍数时
        level = level * (1 + b)                     # 当前退步倍数更新一次
        day += 1                                    # 天数+1
    print("你需要", day, "天", "就达到了原来的", level)

input("运行完毕，请按回车键退出……")
