﻿print('''某人初始感染100个病毒，复制参数由键盘输入，病毒数在10-1000范围内为潜伏期，
超过1000则为症状期，小于10可诊断为痊愈。经过多少个周期后，感染者的转态会有变化，
如转为潜伏期，或者转为痊愈，或始终处于潜伏期？

''')

spread = float(input("请输入病毒复制的速度参数："))      #由键盘来输入复制参数
sum = 100
period = 0                              
while ******:                       #while循环，sum满足什么条件（提示：10-1000为潜伏期）
    sum = ******                    #循环体，sum怎么循环变化（提示：spread为复制参数）
    period =period + 1                  
    if period > 1000:                   
        print("到第{}周期时，病毒数为{},病人仍处于潜伏期。".format(period,sum))
        break                           
if sum <10:                             
    print("到第{}周期时，病毒数变为{},病人已痊愈。".format(period,sum))
elif sum > 1000:
    print("到第{}周期时，病毒数变为{},病人处于症状期。".format(period,sum))
input("运行完毕，请按回车键退出...")
