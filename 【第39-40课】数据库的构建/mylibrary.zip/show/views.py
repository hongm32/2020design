#!/bin/env python
# -*-coding:utf8-*-
# 以上是使用中文的utf8编码

################################################################################################################
#                                             环境配置开始
################################################################################################################                                                                                    

import pyodbc    # 使用odbc连接数据库
import datetime  # 使用日期时间
import time      # 使用时间
import os        # os模块包含了操作系统有关的函数
import sys       # sys模块包含了与Python解释器和它的环境有关的函数

from django.shortcuts import render,render_to_response   
from django.http import HttpResponse, HttpResponseRedirect
from django  import forms

### 图书预约设置的公共变量开始
global count        # 符合查询结果的记录数
global list         # 在图书表中查询书名、出版时间的结果
global bookName     # 书名
global txtTime      # 出版时间
global find_order   # 预约提示信息
### 图书预约设置的公共变量结束

#### 图书表信息类开始   
class BookInfo(object):
    def __init__(self,book_ID,ISBN,bookName,author,bookType,pubTime,number): ## 用于初始化对象
        self.book_ID=book_ID                                    # 书的序号
        self.ISBN=ISBN                                          # 书的ISBN
        self.bookName=bookName                                  # 书名
        self.author=author
        self.bookType=bookType                                  # 类型
        self.pubTime=pubTime                                    # 出版时间
        self.number=number                                      # 数量
#### 图书表信息类结束

#### 借阅表信息类开始
class BorrowInfo(object):  
    def __init__(self,borrow_ID,studentNumber,ISBN,bookName,author,bookType,pubTime,borrowBegin):        ## 用于初始化对象
        self.borrow_ID=borrow_ID                              # 借阅的编号
        self.studentNumber=studentNumber                      # 借阅的人的学号
        self.ISBN=ISBN                                        # 借阅的人的书号
        self.bookName=bookName                                # 图书书名
        self.author=author                                    # 图书作者
        self.bookType=bookType                                # 图书类型
        self.pubTime=pubTime                                  # 出版日期
        self.borrowBegin=borrowBegin                          # 借阅日期        
#### 图书表信息类结束

#### 最受欢迎图书排行榜类开始
class BorrowListInfo(object):  
    def __init__(self,ISBN,bookName,author,bookType,pubTime,borrowCount):        ## 用于初始化对象        
        self.ISBN=ISBN                                        # 借阅的人的书号
        self.bookName=bookName                                # 图书书名
        self.author=author                                    # 图书作者
        self.bookType=bookType                                # 图书类型
        self.pubTime=pubTime                                  # 出版日期
        self.borrowCount=borrowCount                          # 借阅日期        
#### 最受欢迎图书排行榜类开始
################################################################################################################
#                                               环境配置结束
################################################################################################################



################################################################################################################
#                                 第3.3节  任务二  将图书数据录入数据库
# 
# 访问：在浏览器中访问"/bookinsert"
# ##############################################################################################################

def bookinsert(request):
    ### 以下两条语句在python 3.X不需要，只在python 2.7需要
    #reload(sys)                                             # 重新加载sys模块
    #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
    ### 以上两条语句在python 3.X不需要，只在python 2.7需要

    if request.method =='POST':                               # post方法
        userID=request.session.get(u'userID','')              # 获取session的值，没有时为''
        ISBN=request.POST.get('txtISBN')                      # 获取输入的ISBN
        bookTitle=request.POST.get('txtBookTitle')            # 获取输入的书名


        try :          
            #### 以下为第3.3节任务二活动1连接图书数据库的内容
            #conn = pyodbc.connect('DSN=mdb',autocommit=True)  # 用odbc连接DSN为mdb的数据库，修改后自动提交
            DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
            conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交
            cursor = conn.cursor()                            # 用游标方式
            #### 以上为第3.3节任务二活动1连接图书数据库的内容

            #### 以下为第3.3节任务二活动2将图书数据插入数据库的内容

            ## sql语句（插入数据），没有检查数据的重复，即原来有此数据，会再插入一遍
            sql=u""" insert into  [books]([ISBN],[书名]) VALUES  ('%s','%s')""" %(ISBN,bookTitle)

            cursor.execute(sql)                               # 执行SQL语句插入数据

            #### 以上为第3.3节任务二活动2将图书数据插入数据库的内容
            warn= ""                                          # 没有给出反馈信息
        except:                                               # 执行有异常时
        
            warn= u"数据没有录入数据库！"                     # 给出"数据没有录入数据库！"的反馈信息
 
        cursor.close()                                        # 关闭游标
        conn.close()                                          # 关闭数据库连接
        return render_to_response('book_insert.html',{'warn':warn,'user':userID} )    
    else :                                                    # get方法       
        return render(request, 'book_insert.html')
################################################################################################################
#   第3.3节  任务二  将图书数据录入数据库（结束）    
# ##############################################################################################################



################################################################################################################
#                                 第3.3节  拓展练习 第1题  将学生数据录入数据库
# 
# 访问：在浏览器中访问"/insertData"
# ##############################################################################################################

def insertData(request):

    ### 以下两条语句在python 3.X不需要，只在python 2.7需要
    #reload(sys)                                             # 重新加载sys模块
    #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
    ### 以上两条语句在python 3.X不需要，只在python 2.7需要

    if request.method =='POST':                               # post方法
        studentNumber=request.POST.get('txtStudentNumber')    # 获取输入的学号
        studentName=request.POST.get('txtStudentName')        # 获取输入的姓名
        sex=request.POST.get('txtSex')                        # 获取输入的性别
        age=request.POST.get('txtAge')                        # 获取输入的年龄
        grade=request.POST.get('txtGrade')                    # 获取输入的年级
        txtClass=request.POST.get('txtClass')                 # 获取输入的班级

        try :          
            #conn = pyodbc.connect('DSN=mdb',autocommit=True)  # 用odbc连接DSN为mdb的数据库，修改后自动提交
            DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
            conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交
            cursor = conn.cursor()                            # 用游标方式
            ## sql语句（插入数据），没有检查数据的重复，即原来有此数据，会再插入一遍
            sql=u""" insert into  [student]([学号],[密码],[姓名],[性别],[年龄],[年级],[班级]) VALUES  ('%s','%s','%s','%s',%d,'%s','%s')""" %(studentNumber,studentNumber,studentName,sex,int(age),grade,txtClass)

            cursor.execute(sql)                               # 执行SQL语句插入数据
            warn= ""                                          # 没有给出反馈信息
        except:                                               # 执行有异常时
        
            warn= u"数据没有录入数据库！"                     # 给出"数据没有录入数据库！"的反馈信息
 
        cursor.close()                                        # 关闭游标
        conn.close()                                          # 关闭数据库连接
        return render_to_response('insertData.html',{'warn':warn,'user':studentNumber} )    
    else :                                                    # get方法       
        return render(request, 'insertData.html')
################################################################################################################
# 第3.3节  拓展练习 第1题  将学生数据录入数据库（结束）    
# ##############################################################################################################



################################################################################################################
#                                  第3.4节  任务一 活动2  编写用户登录判断程序
# 
# 访问：在浏览器中访问"/login"
# 
# ##############################################################################################################  

def login(request):
    if request.method =='POST':                               # post方法
        
        ### 以下两条语句在python 3.X不需要，只在python 2.7需要
        #reload(sys)                                             # 重新加载sys模块
        #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
        ### 以上两条语句在python 3.X不需要，只在python 2.7需要
        
        ####以下为第3.4节任务一活动2中获取用户信息
        studentNumber=request.POST.get('txtStudentNumber')      # 获取输入的学号
        password=request.POST.get('txtPassword')                # 获取输入的密码
        ####以上为第3.4节任务一活动2中获取用户信息
        
        try :

            ####以下为第3.4节任务一活动2中连接数据库
            DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
            conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交

            cursor = conn.cursor()                            # 用游标方式
            ####以上为第3.4节任务一活动2中连接数据库

            ####以下为第3.4节任务一活动2中查找数据
        
            cursor.execute(u""" Select * FROM [student] where [学号]= '%s'""" %studentNumber)    # 执行SQL查询学生表中的学号=输入的学号的记录

            
            list=cursor.fetchall()                            # 得到查询结果
        
            if list :                                         # 查询结果有内容
                ### 循环遍历，找查询结果中密码等于输入的密码,跳转到"/show"；查询结果中密码不等于输入的密码，给出"密码错！"的反馈信息
                for row in list :                             # 循环遍历                
                    if row[1]==password :                     # 查询结果中密码等于输入的密码
                        request.session['userID']=studentNumber  # 设置session
                        request.session['userName']=row[2]
                        return HttpResponseRedirect("/show")
                    else :                                    # 查询结果中密码不等于输入的密码
                        warn= u"密码错！"                     # 给出"密码错！"的反馈信息
            else :                                            # 数据库查询结果没有内容
                warn = u"用户不存在！请重试"                  # 给出"无此用户！"的反馈信息

            ####以上为第3.4节任务一活动2中查找数据
            
        except:                                               # 执行有异常时
        
            warn= u"不能连接数据库！"                         # 给出"不能连接数据库！"的反馈信息

        return render_to_response('login.html',{'warn':warn,'user':studentNumber} )    
        
        
    else :                                                    # get方法
        return render(request, 'login.html') 
################################################################################################################
#  第3.4节  任务一 活动2  编写用户登录判断程序（结束）
# 
# ############################################################################################################## 



################################################################################################################
#                                  第3.4节  任务二 活动1  根据用户登录信息自动查询借阅信息
# 
# 访问：在浏览器中访问"/showBorrow"
# 
# ##############################################################################################################     

def showBorrow(request):

    ### 以下两条语句在python 3.X不需要，只在python 2.7需要
    #reload(sys)                                             # 重新加载sys模块
    #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
    ### 以上两条语句在python 3.X不需要，只在python 2.7需要    
        
        
        global list                                              # 在借阅表中查询图书借阅信息的结果

        
        userName=request.session.get(u'userName','')             # 获取用户成功登录时保留的姓名
                                                                 #（用于第3.5节 活动2 优化输出的程序实现）
                                                                 
        userID=request.session.get(u'userID','')                 # 获取用户成功登录时保留的学号        
    
        #### 以下为第3.4节任务二活动1连接图书数据库的内容
        DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
        conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交
        cursor = conn.cursor()
        #### 以上为第3.4节任务二活动1连接图书数据库的内容

        
        #### 以下为第3.4节任务二活动1用户信息，查询图书借阅信息的内容
        ### 根据用户登录信息，查询图书借阅信息
        sql=u""" Select * FROM [borrow] where [学号] = '%s'""" %(userID) 
        cursor.execute(sql)                                     # 执行查询SQL语句
        
        list=cursor.fetchall()                                  # 得到查询结果

        # 将查询结果装载到booklist列表中，以便传递到页面
        book_list=[]
        for row in list :                                       # 循环遍历
            book=BorrowInfo(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])        # 生成图书借阅信息的book对象
            book_list.append(book)                              # 将对象添加到传递到页面设计的列表

        return render_to_response('showBorrow.html',{'book_list':book_list} )         
        
   
################################################################################################################
#  第3.4节  任务二 活动1  根据用户登录信息自动查询借阅信息（结束）
# 
# ##############################################################################################################  


################################################################################################################
#                                  第3.4节  任务二 活动2  根据输入数据查询图书
#    
#                                  第3.4节  任务三 活动1  预约图书并更新可借阅图书数量
# 
# 访问：在浏览器中访问"/show"
# 
# ##############################################################################################################  

def show(request):

    ### 以下两条语句在python 3.X不需要，只在python 2.7需要
    #reload(sys)                                             # 重新加载sys模块
    #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
    ### 以上两条语句在python 3.X不需要，只在python 2.7需要
    
    userName=request.session.get(u'userName','没有用户')          # 获取session的值，没有时为'没有用户'
    userID=request.session.get(u'userID','没有用户')              # 获取session的值，没有时为'没有用户'   
    today=time.strftime('%Y-%m-%d',time.localtime(time.time()))  #显示当前日期时间.如格式为：年-月-日 时:分:秒strftime('%Y-%m-%d %H:%M:%S')
    
    
    if request.method =='POST':                                 # post方法
        
        global bookName                                         # 书名
        global txtTime                                          # 出版时间
        global list                                             # 在图书表中查询书名、出版时间的结果
        global count                                            # 符合查询结果的记录数
        global find_order                                       # 预约提示信息
        
        
        DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
        conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交
        cursor = conn.cursor()

        #### 以下为第3.4节任务二活动2的内容查询(支持模糊查询)

        if 'btnFind' in request.POST:
            bookName=(request.POST.get('txtBookName')).strip()      # 获取输入的书名，去除首尾空格            
            txtTime=(request.POST.get('txtTime')).strip()           # 获取输入的出版时间，去除首尾空格            
        

  
            # 第3.4节  任务三 活动1  预约图书并更新可借阅图书数量从此处开始
            # ################################################################################################################

        else:                                                   # 如果是name值为btnOrder的预约按钮,则执行预约功能
            checkbox_list=request.POST.getlist("checkbox")      # 获取用户选择的复选框
            
            num=0                                               #设置选中的图书数量初始值
            ### 遍历查询结果的第一个复选框到最后一个复选框。用户在列表中选择图书，点击预约， 图书数据表数量减少1，借阅图书表增加1条借阅记录。  
            for li in checkbox_list :                           
                # 用户在列表中选择图书， 图书数据表数量减少1（根据被选中行的ISBN值）
                cursor.execute(u""" update [books] set [数量]=[数量]-1 where [ISBN]='%s' """%checkbox_list[num])

                # 借阅表增加1条借阅记录的SQL语句 
                sql=u""" insert into borrow(学号,ISBN,书名,作者,类型,出版时间,借阅日期) select '%s' """%userID                
                sql=sql+u""" ,ISBN,书名,作者,类型,出版时间, '%s' """%today                
                sql=sql+u""" from books where ISBN='%s' """%checkbox_list[num]

                cursor.execute(sql)

                num=num+1

            find_order="您已经成功预约"+str(num)+"本图书！"   

            # 第3.4节  任务三 活动1  预约图书并更新可借阅图书数量  在此处结束
            # ################################################################################################################         



        ### 查询用的SQL语句，根据输入的书名，出版时间查找
        sql=u""" Select TOP 6 * FROM [books] where [数量] > 0 """
        if bookName=='' :                                       # 书名为空
            if not txtTime=='' :                                # 出版时间不为空                    
                sql=sql + u""" and [出版时间] like '%%'+ '%s'+ '%%' """ %txtTime
        else :                                                  # 书名不为空  
            if  txtTime=='' :                                   # 出版时间为空                    
                sql=sql + u""" and [书名] like '%%'+'%s'+'%%' """ %bookName
            else :                                              # 出版时间不为空                    
                sql=sql + u""" and [书名] like '%%'+'%s'+'%%' and [出版时间]= '%s'""" %(bookName,txtTime)
        
        cursor.execute(sql)                                     # 执行查询SQL语句
        
        list=cursor.fetchall()                                  # 得到查询结果（在图书表中查询书名、出版时间的结果）

        book_list=[]                                            # 图书表的信息
        count=0
        for row in list :                                       # 循环遍历
            count=count+1                                       # 符合查询结果的记录数
            book=BookInfo( "%i"%count,row[0],row[1],row[2],row[3],row[4],row[5])       # 生成图书信息的book对象
            book_list.append(book)                              # 将对象添加到传递到页面设计的列表
        
        # 优化输出的实现 之 提示操作的结果（用于第3.5节 任务二 活动2）
        if 'btnOrder' in request.POST:
            find=find_order
        else: 
            if bookName=='' :                                       # 书名为空
                if txtTime=='' :                                    # 出版时间为空
                    find = u""" 共有%s 条记录""" %(count)            # 提示信息:用户，记录数
                else :                                              # 出版时间不为空
                    find = u""" 出版时间： %s  ,共有%s 条记录""" %(txtTime,count)    # 提示信息:用户，出版时间，记录数
            else :                                                  # 书名不为空
                if  txtTime=='' :                                   # 出版时间为空
                    find = u""" 书名： %s    ,共有%s 条记录""" %(bookName,count)     # 提示信息:用户，书名，记录数
                else :                                              # 出版时间不为空
                    find = u""" 书名： %s  ,     出版时间： %s  ,共有%s 条记录""" %(bookName,txtTime,count)    # 提示信息:用户，书名，出版时间，记录数
   
        # 参数find用于显示操作的结果； userName用于显示欢迎信息； today用于显示当前日期
        return render_to_response('show.html',{'book_list':book_list,'find':find,'userName':userName,'today':today}) 

        #### 访问"/show"，图书预约界面结束 
        
                                    
    else :
        return render_to_response('show.html',{'userName':userName,'today':today})



################################################################################################################
#    第3.4节  任务二 活动2  根据输入数据查询图书 （结束）
#    
#    第3.4节  任务三 活动1  预约图书并更新可借阅图书数量 （结束）
# 
# ############################################################################################################## 



################################################################################################################
#                                  第3.5节  任务一 活动2  编写最受欢迎的图书排行榜程序
#    
# 访问：在浏览器中访问"/show"
# 
# ##############################################################################################################

def showNew(request):

    ### 以下两条语句在python 3.X不需要，只在python 2.7需要
    #reload(sys)                                             # 重新加载sys模块
    #sys.setdefaultencoding('utf-8')                         # 当前的ascii模式修改为utf-8编码模式
    ### 以上两条语句在python 3.X不需要，只在python 2.7需要
        
    global list                                             # 在借阅表中查询图书借阅信息的结果      
    
    # 连接数据库
    DBfile =os.getcwd()+ u"""\图书借阅管理.mdb"""  # 起始执行目录\数据库文件
    conn = pyodbc.connect(u"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + DBfile + ";Uid=;Pwd=;",autocommit=True)# 用odbc连接DSN为mdb的数据库，修改后自动提交
    cursor = conn.cursor()
    #### 以上为第3.5节任务一活动2连接图书数据库的内容    
    
    ### 查询用的SQL语句，查询最受欢迎的图书借阅排行榜（考虑到网页页面高度，只查询前面5条数据）
    sql= "Select top 5 [ISBN],书名,作者,类型,出版时间 ,count(*) as 借阅次数  FROM  [borrow] group by [ISBN],书名,作者,类型,出版时间 order by 6 DESC"""    
    cursor.execute(sql)                                     # 执行查询SQL语句    
    list=cursor.fetchall()                                  # 得到查询结果（在图书借阅排行榜的结果）    
    
    book_list=[]                                            # 查询图书借阅排行榜信息的结果，为了传递到页面设计的列表

    ### 将在借阅表中查询借阅排行榜的结果，传递到页面的列表中
    for row in list :                                       # 循环遍历
        book=BorrowListInfo(row[0],row[1],row[2],row[3],row[4],row[5])                  # 生成图书借阅排行榜信息的book对象
        book_list.append(book)                              # 将对象添加到传递到页面设计的列表

    return render_to_response('showNew.html',{'book_list':book_list} )   
        
    
################################################################################################################
#    第3.5节  任务一 活动2  编写最受欢迎的图书排行榜程序 （结束）
# 
# ##############################################################################################################


