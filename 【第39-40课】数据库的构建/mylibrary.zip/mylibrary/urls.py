# -*-coding:utf8-*-
"""mylibrary URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.dinco, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

from show import views as show_views 

 
urlpatterns = [     
    url(r'^$', show_views.login),                                     #设置网站的默认起始页
    url(r'^login/$', show_views.login, name='login'),                 #用户登录页面
    url(r'^show/$', show_views.show, name='show'),                    # 用户正确登录后访问的页面。
                                                                      #（续前一行注释） 显示欢迎信息，导航信息，
                                                                      #（续前一行注释） 学生当前借阅图书的信息和图书搜索信息
    
    url(r'^insertData/$', show_views.insertData, name='insertData'),  # 插入学生信息的页面
    url(r'^bookinsert/$', show_views.bookinsert, name='bookinsert'),  # 插入图书信息的页面
    url(r'^showBorrow/$', show_views.showBorrow, name='showBorrow'),  # 浏览用户借阅情况的页面
    url(r'^showNew/$', show_views.showNew, name='showNew'),           # 浏览最受欢迎的图书排行榜页面

]



