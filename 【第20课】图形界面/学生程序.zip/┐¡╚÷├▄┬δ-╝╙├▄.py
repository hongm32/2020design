﻿import tkinter       # 导入tkinter模块


def jiami():               # “加密”按钮激发函数  
    c = txt1.get("0.0", "end")   # 获取mingwen对象的内容（明文）
    b = ""
    txt2.delete("0.0", "end")    # 清空miwen对象的内容
    for i in range(len(c)):       # 获取明文内容的每一个字符，并加密
        if 'a' <= c[i] <= 'w' or 'A' <= c[i] <= 'W':   # 判断a～w或A～W间的字母
            b += chr(ord(c[i])+3)               # 生成密文
        elif 'x' <= c[i] <= 'z' or 'X' <= c[i] <= 'Z':  # 判断x～z或X～Z间的字母
            b += chr(ord(c[i])-23)              # 生成密文
        else:
            b += c[i]                           # 字母以外的明文不变
    txt2.insert("0.0", b)                       # 在miwen对象中显示结果


root = tkinter.Tk()         # 建立一个窗口 
root.title("凯撒密码")      # 设置窗口标题 
root.geometry('300x200')    # 设置窗口大小
lbl1 = tkinter.Label(root, text='请输入明文', font=('Arial', 10))
lbl1.pack()
txt1 = tkinter.Text(root,width=300,height=4)
txt1.pack()
txt1.focus_set()    # 获得焦点
btn1 = tkinter.Button(root, text="加密", command=jiami, width=10)
btn1.pack()
lbl2 = tkinter.Label(root, text='凯撒密文', font=('Arial', 10))
lbl2.pack()
txt2 = tkinter.Text(root, width=300, height=4)
txt2.pack()

root.mainloop()
