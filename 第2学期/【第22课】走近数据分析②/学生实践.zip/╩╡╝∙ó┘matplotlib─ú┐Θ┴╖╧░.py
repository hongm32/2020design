import matplotlib.pyplot as plt      # 导入matplotlib库的子库pyplot库并取别名为plt

x = [1, 2, 3, 5, 6, 8]
y = [1, 7, 25, 11, 10, 2]     # 定义两个列表用于存储x和y轴的变量

#？      # 绘制折线图
#？      # 显示图表
