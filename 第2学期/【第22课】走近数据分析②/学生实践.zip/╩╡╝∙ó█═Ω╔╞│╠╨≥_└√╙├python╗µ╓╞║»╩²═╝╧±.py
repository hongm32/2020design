#？  # 加载numpy模块并取名为np
import matplotlib.pyplot as plt  # 加载matplotlib.pyplot并取名为plt



#？  # x在0到2π之间，每隔0.01取一个点
#？ 		               # 求sin(x)对应的列表y1的值
y2 = np.sin(-x)		               # 求sin(-x)对立的列表y2的值
#？             # 求sin(2x)/2对应的列表y3的值

plt.plot(x, y1)		     # 绘制sin(x)的图像
#？          # 绘制sin(-x)的图像
#？          # 绘制sin(2x)/2的图像

plt.title('正弦函数图像', size=18)  # 设置图像标题
plt.xlabel('X')  # 设置X轴标题
plt.ylabel('Y')  # 设置Y轴标题
plt.show()  # 将绘制的函数图像窗口显示出来
